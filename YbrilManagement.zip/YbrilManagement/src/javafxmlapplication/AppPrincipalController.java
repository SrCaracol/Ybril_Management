/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;

/**
 * FXML Controller class
 *
 * @author carlosalbeldo
 */
public class AppPrincipalController implements Initializable {

    @FXML
    private Button bEditarPerfil;
    @FXML
    private Button bGastos;
    @FXML
    private Button bCrearGasto;
    @FXML
    private Button bCategorias;
    @FXML
    private Button bTablaBarras;
    @FXML
    private Button bTablaQueso;
    @FXML
    private Button tablaLineas;
    @FXML
    private Button bSalir;
    @FXML
    private DatePicker desdeDP;
    @FXML
    private DatePicker hastaDP;
    @FXML
    private Button bImprimir;
    @FXML
    private Button bModificarGasto;
    @FXML
    private Button bBorrarGasto;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleBEditarPerfil(ActionEvent event) {
    }

    @FXML
    private void handleBGastos(ActionEvent event) {
    }

    @FXML
    private void handleBCrearGasto(ActionEvent event) {
    }

    @FXML
    private void handleBCategorias(ActionEvent event) {
    }

    @FXML
    private void handleBTablasBarras(ActionEvent event) {
    }

    @FXML
    private void handleBTableQueso(ActionEvent event) {
    }

    @FXML
    private void handleBTablaLineas(ActionEvent event) {
    }

    @FXML
    private void handleBSalir(ActionEvent event) {
    }
    
    
    //codi DatePicker Desde
    @FXML
    private void handleDesdeDP(ActionEvent event) {
        desdeDP.setDayCellFactory(picker -> new DateCell(){
            @Override
            public void updateItem(LocalDate date, boolean empty){
                super.updateItem(date, empty);
                LocalDate today = LocalDate.now();
                setDisable(empty || date.compareTo(today) < 0);
            }
        });
    }
    // codi DatePicker hasta
    @FXML
    private void handleHastaDP(ActionEvent event) {
        hastaDP.setDayCellFactory(picker -> new DateCell(){
            @Override
            public void updateItem(LocalDate date, boolean empty){
                super.updateItem(date, empty);
                LocalDate today = LocalDate.now();
                setDisable(empty || date.compareTo(today) > 0);
            }
        });
    }

    @FXML
    private void handleBImprimir(ActionEvent event) {
    }

    @FXML
    private void handleBModificarGasto(ActionEvent event) {
    }

    @FXML
    private void handleBBorrarGasto(ActionEvent event) {
    }
    
    
    
}
