/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmlapplication;

import java.io.File;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.net.URL;
import java.time.LocalDate;
import javafx.scene.image.Image;
import model.Acount;
import model.AcountDAOException;
import model.User;


/**
 *
 * @author jsoler
 */
public class FXMLDocumentController implements Initializable {

    //Objetos Iniciar Sesión
    @FXML
    private TextField nickUsuario;
    @FXML
    private TextField contraseñaUsuario;
    @FXML
    private Button bSalir;
    
    //Objetos Registrar Usuario
    private Button bVolver;
    private ImageView fotoPerfil;
    @FXML
    private Hyperlink linkRegistrarse;
    @FXML
    private Button bIniciarSesion;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    //Iniciar Sesión Métodos
    @FXML
    private void handleLinkRegistro(ActionEvent event) throws IOException {
        FXMLLoader loader= new FXMLLoader(getClass().getResource("RegistrarUsuario.fxml"));
        Parent root = loader.load();
        RegistrarUsuarioController controllerRegistrar = loader.getController();
        
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Registrar");
        stage.initModality(Modality.APPLICATION_MODAL);
        //stage.show();
        stage.showAndWait();
    }

    @FXML
    private void handleBSalir(ActionEvent event) {
        if (this.bSalir != null) {
            bSalir.getScene().getWindow().hide();
        }
    }

    
    //Registrar Usuario Métodos
    
    //Per alguna rao no va en RegistrarUsuarioController.java, pero asi si xd
    private void handleBVolver(ActionEvent event) {
        bVolver.getScene().getWindow().hide();
    }
    
    

    @FXML
    private void handlebIniciarSesion(ActionEvent event) throws IOException, AcountDAOException {
        
        boolean inicioSesion = Acount.getInstance().logInUserByCredentials(nickUsuario.getText(), contraseñaUsuario.getText());
        
        if(inicioSesion){
            FXMLLoader loader= new FXMLLoader(getClass().getResource("AppPrincipal.fxml"));
            Parent root = loader.load();
            AppPrincipalController controllerApp = loader.getController();

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setTitle("YbrilManagement");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
        }
    }
}
