/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Acount;
import model.AcountDAOException;
import model.Category;

/**
 * FXML Controller class
 *
 * @author galco
 */
public class CategoriasController implements Initializable {

    @FXML
    private Button bCrearCategoria;
    @FXML
    private Button bModificarCategoria;
    @FXML
    private Button bBorarCategoria;
    @FXML
    private Button bVolver;
    
    private Acount cuentaActual;
    
    private ObservableList<Category> categorias = null;
    @FXML
    private ListView<Category> categoriasListView;
    
    private Acount miscategorias;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            miscategorias.getInstance();
        } catch (AcountDAOException ex) {
            Logger.getLogger(CategoriasController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CategoriasController.class.getName()).log(Level.SEVERE, null, ex);
        }
        List<Category> categoriasDelUsuario = null;
        try {
            categoriasDelUsuario = miscategorias.getUserCategories();
        } catch (AcountDAOException ex) {
        }
        categorias = FXCollections.observableList(categoriasDelUsuario);
        categoriasListView.setItems(categorias);
        categoriasListView.setCellFactory((c)-> new MiCelda());
        bCrearCategoria.setDisable(true);
        // si no hay selección el boton Borrar esta disabled
        bBorarCategoria.disableProperty().bind(Bindings.equal(categoriasListView.getSelectionModel().selectedIndexProperty(), -1));
        // si no hay selección el boton Modificar esta disabled
        bModificarCategoria.disableProperty().bind(Bindings.equal(categoriasListView.getSelectionModel().selectedIndexProperty(), -1));
        
    }    

    @FXML
    private void handleBCrearCategoria(ActionEvent event) throws IOException {
        
        FXMLLoader miCargador = new FXMLLoader(getClass().getResource("/CrearCategoria.fxml"));
        Stage stage = miCargador.load();  // el fxml contiene como raíz a un stage, lo puedes ver en el Scene Builder
        
        CrearCategoriaController controlCategoria = miCargador.getController();
        stage.setTitle("Crear Categoria");
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.showAndWait();
        if(controlCategoria.iscrearPressed()){
            Category c = controlCategoria.getCategory();
            categorias.add(c);
            
        }
        
    }

    @FXML
    private void handleBModificarCategoria(ActionEvent event) throws IOException {
        FXMLLoader miCargador = new FXMLLoader(getClass().getResource("/EditarCategoria.fxml"));
        Stage stage = miCargador.load();  
        
        EditarCategoriaController controlCategoria = miCargador.getController();
        Category categoria = categoriasListView.getSelectionModel().getSelectedItem();
        controlCategoria.initCategoria(categoria);
        
        stage.setTitle("Modificar Categoria");
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.showAndWait();
        
        if(controlCategoria.iscrearPressed()){
            int indice = categorias.indexOf(categoria);
             Category c = controlCategoria.getCategory();
             categorias.set(indice, c);
        }
        
    }

    @FXML
    private void handleBBorrarCategoria(ActionEvent event) {
        categorias.remove(categoriasListView.getSelectionModel().getSelectedIndex());
        
        
    }

    @FXML
    private void handleBVolver(ActionEvent event) {
        Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
        Stage stage = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
        stage.close();  
    }
    
}
class MiCelda extends ListCell<Category>{

        @Override
        protected void updateItem(Category t, boolean bln) {
            super.updateItem(t, bln); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
            if(bln){
                setText(null);
            } else{
                setText(t.getDescription()+",  "+t.getName());
            }
        }
}
