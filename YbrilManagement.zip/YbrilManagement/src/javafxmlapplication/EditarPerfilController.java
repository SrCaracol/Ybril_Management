/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author carlosalbeldo
 */
public class EditarPerfilController implements Initializable {

    @FXML
    private TextField nombreUsuario;
    @FXML
    private TextField apellidosUsuario;
    @FXML
    private TextField nickUsuario;
    @FXML
    private Button bVolver;
    @FXML
    private Button bAceptarEditar;
    @FXML
    private TextField correoUsuario;
    @FXML
    private ImageView fotoPerfil;
    @FXML
    private Button bEliminarFoto;
    @FXML
    private Button bExplorarFoto;
    @FXML
    private TextField contraseñaUsuario;
    @FXML
    private TextField confirmarContraseña;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleBVolverOnAction(ActionEvent event) {
    }

    @FXML
    private void handleBAceptarEditar(ActionEvent event) {
    }

    @FXML
    private void handleBEliminarFotoOnAction(ActionEvent event) {
    }

    @FXML
    private void handleBExplorarFotoOnAction(ActionEvent event) {
    }
    
}
