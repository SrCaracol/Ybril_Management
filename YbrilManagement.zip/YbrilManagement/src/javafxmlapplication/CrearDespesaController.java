/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author carlosalbeldo
 */
public class CrearDespesaController implements Initializable {

    @FXML
    private TextField nombreGasto;
    @FXML
    private TextField precioGasto;
    @FXML
    private TextField descripcionGasto;
    @FXML
    private Button bCancelar;
    @FXML
    private Button bCrear;
    @FXML
    private DatePicker fechaGasto;
    @FXML
    private ImageView fotoPerfil;
    @FXML
    private Button bEliminarTicket;
    @FXML
    private Button bExplorarTicket;
    @FXML
    private ChoiceBox<?> categoriasGasto;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleBCancelar(ActionEvent event) {
    }

    @FXML
    private void handleBCrear(ActionEvent event) {
    }

    @FXML
    private void handleBEliminarTicket(ActionEvent event) {
    }

    @FXML
    private void handleBExplorarTicket(ActionEvent event) {
    }
    
}
