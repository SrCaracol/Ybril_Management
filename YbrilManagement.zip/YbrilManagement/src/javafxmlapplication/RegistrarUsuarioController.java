/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxmlapplication;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.time.LocalDate;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Acount;
import model.AcountDAOException;
import model.User;

/**
 *
 * @author galco
 */
public class RegistrarUsuarioController {

    @FXML
    private TextField nombreUsuario;
    @FXML
    private TextField apellidosUsuario;
    @FXML
    private TextField nickUsuario;
    @FXML
    private Button bVolver;
    @FXML
    private Button bRegistrarse;
    @FXML
    private TextField correoUsuario;
    @FXML
    private Button bEliminarFoto;
    @FXML
    private Button bExplorarFoto;
    @FXML
    private ImageView fotoPerfil;
    @FXML
    private TextField confirmarContraseña;
    @FXML
    private TextField contraseñaUsuario;

    @FXML
    private void handleBVolver(ActionEvent event) {
        Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
        Stage stage = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
        stage.close();                          //Me cierra la ventana
    }

  
    
    private void controlDeErrores(){}


    @FXML
    private void handleRegistrarUsuario(ActionEvent event) throws AcountDAOException, IOException {
        //if(User.checkEmail(correoUsuario.getText()) == true && User.checkNickName(nickUsuario.getText()) == true && User.checkPassword(contraseñaUsuario.getText()) == true){
            boolean registrado = Acount.getInstance().registerUser(nombreUsuario.getText(), apellidosUsuario.getText(), correoUsuario.getText(), nickUsuario.getText(), contraseñaUsuario.getText(), fotoPerfil.getImage(), LocalDate.MAX);
            Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
            Stage stage = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
            stage.close();                          //Me cierra la ventana
        //} else{controlDeErrores();}
        //prueba();
        
    }

    private void prueba(){
        if(User.checkPassword(contraseñaUsuario.getText())){
            System.out.println("true");
        }else{System.out.println("false");}
    }
    
    
    
    
    
    
    @FXML
    private void handleBExplorarFoto(ActionEvent event) throws MalformedURLException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Obrir fitxer");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Imatges", "*.png", "*.jpg", "*.gif","*.jpeg"),
            new FileChooser.ExtensionFilter("Tots", "*.*"));
        File selectedFile = fileChooser.showOpenDialog(((Node)event.getSource()).getScene().getWindow());

        String imageUrl = selectedFile.toURI().toURL().toString();
        Image image = new Image(imageUrl);
        fotoPerfil.setImage(image);
    }
    
    @FXML
    private void handleBEliminarFoto(ActionEvent event) throws MalformedURLException {
        File file = new File("src/fotoperfil.png");
        String direccion =  file.toURI().toURL().toString() ;
        Image image = new Image(direccion);
        fotoPerfil.setImage(image);
    }

    
}
