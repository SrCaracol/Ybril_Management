/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.io.IOException;
import java.net.URL;
import model.Category;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import model.User;
import model.Acount;
import model.AcountDAOException;

/**
 * FXML Controller class
 *
 * @author carlosalbeldo
 */
public class CrearCategoriaController implements Initializable {

    @FXML
    private TextField nombreCategoria;
    @FXML
    private TextField DescripcionCategoria;
    @FXML
    private Button bCancelar;
    @FXML
    private Button bCrear;
    
    private boolean crearPressed = false;
    
    private Category categoria;
    
    private Acount cuentaActual;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            cuentaActual = Acount.getInstance();
        } catch (AcountDAOException ex) {
            Logger.getLogger(CrearCategoriaController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CrearCategoriaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void handleBCancelar(ActionEvent event) {
         nombreCategoria.getScene().getWindow().hide();
    }

    @FXML
    private void handleBCrear(ActionEvent event) throws AcountDAOException {
        
        String nombre = nombreCategoria.getText();
        String descripcion = DescripcionCategoria.getText();
        if(!nombre.equals("") && !descripcion.equals("")){
            
            boolean sePuedeCrearCategoria = cuentaActual.registerCategory(nombre,descripcion);
            
            if(sePuedeCrearCategoria){
                crearPressed = true;
                nombreCategoria.getScene().getWindow().hide();
            }
        }
    }
    
    public boolean iscrearPressed(){
        return crearPressed;
    }
    
    public Category getCategory(){
        return categoria;
    }
    
    
    
}
