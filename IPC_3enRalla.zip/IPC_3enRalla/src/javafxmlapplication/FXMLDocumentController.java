/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmlapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

/**
 *
 * @author jsoler
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private Button boton1;
    @FXML
    private Button reiniciar;
    @FXML
    private Text jugada1;
    private int jugador;
    @FXML
    private Button boton2;
    @FXML
    private Button boton3;
    @FXML
    private Button boton4;
    @FXML
    private Button boton5;
    @FXML
    private Button boton6;
    @FXML
    private Button boton7;
    @FXML
    private Button boton8;
    @FXML
    private Button boton9;
    @FXML
    private Text jugada2;
    @FXML
    private Text jugada3;
    @FXML
    private Text jugada5;
    @FXML
    private Text jugada6;
    @FXML
    private Text jugada7;
    @FXML
    private Text jugada8;
    @FXML
    private Text jugada9;
    @FXML
    private Text jugada4;
    
    //=========================================================
    // you must initialize here all related with the object 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  

    @FXML
    private void nuevaPartida(ActionEvent event) {
        jugador = 0;
        jugada1.setText("");
        boton1.setDisable(false);
        jugada2.setText("");
        boton2.setDisable(false);
        jugada3.setText("");
        boton3.setDisable(false);
        jugada4.setText("");
        boton4.setDisable(false);
        jugada5.setText("");
        boton5.setDisable(false);
        jugada6.setText("");
        boton6.setDisable(false);
        jugada7.setText("");
        boton7.setDisable(false);
        jugada8.setText("");
        boton8.setDisable(false);
        jugada9.setText("");
        boton9.setDisable(false);
    }

    @FXML
    private void movimiento1(ActionEvent event) {
        if(jugador % 2 == 0){
            jugada1.setText("X");
            jugador++;
            boton1.setDisable(true);
        }else{
            jugada1.setText("O");
            jugador++;
            boton1.setDisable(true);
            
        }
    }

    @FXML
    private void movimiento2(ActionEvent event) {
        if(jugador % 2 == 0){
            jugada2.setText("X");
            jugador++;
            boton2.setDisable(true);
        }else{
            jugada2.setText("O");
            jugador++;
            boton2.setDisable(true);
            
        }
    }

    @FXML
    private void movimiento3(ActionEvent event) {
        if(jugador % 2 == 0){
            jugada3.setText("X");
            jugador++;
            boton3.setDisable(true);
        }else{
            jugada3.setText("O");
            jugador++;
            boton3.setDisable(true);
            
        }
    }

    @FXML
    private void movimiento4(ActionEvent event) {
        if(jugador % 2 == 0){
            jugada4.setText("X");
            jugador++;
            boton4.setDisable(true);
        }else{
            jugada4.setText("O");
            jugador++;
            boton4.setDisable(true);
            
        }
    }

    @FXML
    private void movimiento5(ActionEvent event) {
        if(jugador % 2 == 0){
            jugada5.setText("X");
            jugador++;
            boton5.setDisable(true);
        }else{
            jugada5.setText("O");
            jugador++;
            boton5.setDisable(true);
            
        }
    }

    @FXML
    private void movimiento6(ActionEvent event) {
        if(jugador % 2 == 0){
            jugada6.setText("X");
            jugador++;
            boton6.setDisable(true);
        }else{
            jugada6.setText("O");
            jugador++;
            boton6.setDisable(true);
            
        }
    }

    @FXML
    private void movimiento7(ActionEvent event) {
        if(jugador % 2 == 0){
            jugada7.setText("X");
            jugador++;
            boton7.setDisable(true);
        }else{
            jugada7.setText("O");
            jugador++;
            boton7.setDisable(true);
            
        }
    }

    @FXML
    private void movimiento8(ActionEvent event) {
        if(jugador % 2 == 0){
            jugada8.setText("X");
            jugador++;
            boton8.setDisable(true);
        }else{
            jugada8.setText("O");
            jugador++;
            boton8.setDisable(true);
            
        }
    }

    @FXML
    private void movimiento9(ActionEvent event) {
        if(jugador % 2 == 0){
            jugada9.setText("X");
            jugador++;
            boton9.setDisable(true);
        }else{
            jugada9.setText("O");
            jugador++;
            boton9.setDisable(true);
            
        }
    }
    
}
